# Web Scraping & Data Analysis – Online Bookstore

## Project overview
A beginner-friendly Python project that scrapes book listings from the practice website Books to Scrape, cleans the records using pandas, performs exploratory data analysis, and exports a CSV dataset.

## Tools
- Python
- Requests
- BeautifulSoup
- Pandas
- Matplotlib
- Jupyter Notebook

## Dataset fields
- title
- price_gbp
- availability
- rating
- product_url

## How to run
1. Install Python and Jupyter Notebook.
2. Open a terminal in this project folder.
3. Run: `pip install -r requirements.txt`
4. Start Jupyter: `jupyter notebook`
5. Open `Web_Scraping_Bookstore_Project.ipynb`.
6. Run the notebook cells from top to bottom.
7. The output file `scraped_books_data.csv` will be saved in the same folder.

## Learning and responsible-use note
This project uses Books to Scrape, a website made for practising web scraping. For other websites, check their terms, robots.txt, rate limits, and permissions first. Do not scrape private, login-protected, or personal information. Keep request rates low.

## Author
Add your name and course details here before publishing to GitHub.
